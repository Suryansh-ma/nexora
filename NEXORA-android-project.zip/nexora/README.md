# NEXORA — YouTube-only Android browser with the Desktop GIFs extension pre-installed

Kotlin + **GeckoView** (Gecko engine, WebExtensions). Android WebView cannot run browser extensions, so it is not used.

* Allowed browsing: `https://www.youtube.com` and the native page `nexora://extensions`. Everything else is denied (top-level, redirects, popups, iframes).
* YouTube is always loaded in desktop mode (GeckoView desktop user-agent + desktop viewport).
* Desktop GIFs 0.1.8 is bundled unmodified in the APK and installed on every launch via GeckoView's built-in-extension mechanism. Nothing is downloaded.

## Build (needs internet; JDK 17, Android SDK 35)
```bash
# one-time: create the wrapper jar (the wrapper properties are included)
gradle wrapper --gradle-version 8.9
./gradlew :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
Or open the folder in Android Studio (Ladybug or newer) and press Run. Or push to GitHub: `.github/workflows/build.yml` builds the debug APK and uploads it as an artifact.

**GeckoView version:** `gradle.properties` → `geckoviewVersion` (must be ≥ 140, the extension's `strict_min_version`). The pinned value could not be checked against maven.mozilla.org when this was written; if Gradle cannot resolve it, pick any listed 14x+ version from https://maven.mozilla.org/?prefix=maven2/org/mozilla/geckoview/geckoview/ .

**Release APK:** create a keystore, add a `signingConfigs` block and `signingConfig` to the `release` build type, then `./gradlew :app:assembleRelease`.

**Verify the bundled extension:** `scripts/verify-extension.sh desktop_gifs-main.zip`

## Layout
| Path | What |
| --- | --- |
| `app/src/main/java/app/nexora/browser/UrlPolicy.kt` | allow-list (single source of truth) |
| `.../ExtensionHost.kt` | installs/enables the bundled extension |
| `.../ExtensionsPage.kt` | native `nexora://extensions` page |
| `.../MainActivity.kt` | toolbar, address bar, progress, fullscreen, back handling |
| `app/src/main/assets/extensions/desktop-gifs/` | the extension, unmodified |

## Behaviors you should know about
1. **Sign-in is allowed.** Besides `www.youtube.com`, the policy also allows `accounts.google.com` and `accounts.youtube.com` so you can log in (needed to comment). Set `UrlPolicy.ALLOW_GOOGLE_SIGN_IN = false` for a youtube.com-only policy. Google may add extra steps (e.g. other hosts) that stay blocked; if a login step is denied, tell me which host.
2. **Posting GIFs is reported broken upstream** (YouTube rejects desktop GIF comments since 14 Oct 2026, per the extension README). NEXORA makes no claim that posting works.
3. **Network scope.** GeckoView gives apps no per-subresource filter, so the allow-list governs navigations. The extension's own network access is limited by its manifest (+ CORS): tenor.com, tenor.googleapis.com, media*.tenor.com, api.github.com (daily update-check), www.youtube.com.
4. `background.service_worker` in the manifest is ignored by Gecko, which runs `src/sw.js` as a background event page (`background.scripts`) — the manifest provides both keys for exactly this reason. All other APIs used (`scripting`, `storage`, MAIN-world content scripts, `runtime.sendMessage`) are standard Gecko 140+ WebExtension APIs.
5. `chrome.tabs.query` / `scripting.executeScript` in `sw.js`'s `onInstalled` only matter for tabs already open at install time; NEXORA installs the extension before the first page loads, so the static `content_scripts` cover it.

## License
GPL-3.0-only. See `LICENSE` and `THIRD_PARTY_NOTICES.md`.
