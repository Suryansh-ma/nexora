/*
 * Copyright (C) 2026 NEXORA contributors
 * SPDX-License-Identifier: GPL-3.0-only
 */
package app.nexora.browser

import android.app.Application
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings

class NexoraApp : Application() {
    /**
     * Lazy on purpose: GeckoView starts extra processes (:tab, :gpu, ...) that also instantiate
     * the Application class. Only the main process ever touches [runtime], so only it creates one.
     */
    val runtime: GeckoRuntime by lazy {
        val settings = GeckoRuntimeSettings.Builder()
            .javaScriptEnabled(true)
            .aboutConfigEnabled(false)
            .extensionsWebAPIEnabled(false)
            .remoteDebuggingEnabled(BuildConfig.DEBUG)
            .consoleOutput(BuildConfig.DEBUG)
            .preferredColorScheme(GeckoRuntimeSettings.COLOR_SCHEME_DARK)
            .build()
        GeckoRuntime.create(this, settings)
    }
}
