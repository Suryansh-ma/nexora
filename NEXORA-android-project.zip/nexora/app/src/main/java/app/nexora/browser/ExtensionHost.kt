/*
 * Copyright (C) 2026 NEXORA contributors
 * SPDX-License-Identifier: GPL-3.0-only
 */
package app.nexora.browser

import android.content.Context
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

/**
 * Installs the bundled Desktop GIFs extension into GeckoView on every launch.
 *
 * The extension lives unmodified in assets/extensions/desktop-gifs/ and is loaded through
 * GeckoView's built-in-extension mechanism (resource://android/assets/...), so nothing is
 * downloaded and the user installs nothing. The extension keeps the same ID
 * (desktop-gifs@rayytor) across launches and app updates, so its chrome.storage.local data
 * (favorites) stays in the Gecko profile.
 */
class ExtensionHost(context: Context, private val runtime: GeckoRuntime) {
    companion object {
        const val EXTENSION_ID = "desktop-gifs@rayytor"
        const val EXTENSION_URI = "resource://android/assets/extensions/desktop-gifs/"
        const val ASSET_DIR = "extensions/desktop-gifs"
        private const val PREFS = "nexora"
        private const val KEY_ENABLED = "desktop_gifs_enabled"
    }

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val controller: WebExtensionController get() = runtime.webExtensionController

    var extension: WebExtension? = null
        private set
    var installError: String? = null
        private set

    /** The user's choice from the Extensions page (default: enabled). */
    val userEnabled: Boolean get() = prefs.getBoolean(KEY_ENABLED, true)

    /** Installs (or re-attaches to) the bundled extension, then applies the user's enable choice. */
    fun ensureInstalled(done: (WebExtension?) -> Unit) {
        controller.ensureBuiltIn(EXTENSION_URI, EXTENSION_ID).then<Void>(
            { ext: WebExtension? ->
                extension = ext
                installError = null
                if (ext == null) done(null) else applyUserState(ext, done)
                null
            },
            { t: Throwable ->
                installError = t.message ?: t.javaClass.simpleName
                done(null)
                null
            }
        )
    }

    fun setEnabled(enabled: Boolean, done: (WebExtension?) -> Unit) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply()
        val ext = extension ?: return done(null)
        applyUserState(ext, done)
    }

    private fun applyUserState(ext: WebExtension, done: (WebExtension?) -> Unit) {
        val want = userEnabled
        if (ext.metaData.enabled == want) {
            done(ext)
            return
        }
        val request = if (want) controller.enable(ext, WebExtensionController.EnableSource.USER)
        else controller.disable(ext, WebExtensionController.EnableSource.USER)
        request.then<Void>(
            { updated: WebExtension? ->
                extension = updated ?: ext
                done(extension)
                null
            },
            { t: Throwable ->
                installError = t.message ?: t.javaClass.simpleName
                done(ext)
                null
            }
        )
    }
}
