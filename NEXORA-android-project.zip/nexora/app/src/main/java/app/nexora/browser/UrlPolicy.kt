/*
 * NEXORA - Android browser shell for YouTube + the bundled Desktop GIFs extension.
 * Copyright (C) 2026 NEXORA contributors
 * SPDX-License-Identifier: GPL-3.0-only
 */
package app.nexora.browser

import java.net.URI
import java.net.URLEncoder

/**
 * The single place that decides which pages NEXORA may open.
 *
 * Only https://www.youtube.com is allowed for top-level navigation, redirects and iframes.
 * The internal page nexora://extensions is handled natively and is reachable only from the
 * address bar / toolbar, never from web content.
 *
 * Scope note: GeckoView exposes no per-subresource interception API to an app, so this policy
 * governs navigations (top-level, redirects, popups, sub-frames). Subresources (video
 * streams, thumbnails) load normally because YouTube cannot work without them. The extension's
 * own requests are bounded by its manifest (host_permissions: tenor.com, www.youtube.com).
 */
object UrlPolicy {
    const val HOME = "https://www.youtube.com/"
    const val EXTENSIONS_URL = "nexora://extensions"

    /**
     * Posting a comment needs a signed-in YouTube session, and Google sign-in lives on
     * accounts.google.com. Enabled at the owner's request: this additionally allows the
     * Google/YouTube sign-in hosts (accounts.google.com, accounts.youtube.com). Set to false
     * and rebuild for the strictest policy (youtube.com only).
     */
    const val ALLOW_GOOGLE_SIGN_IN = true

    private const val YOUTUBE_HOST = "www.youtube.com"
    private val SIGN_IN_HOSTS = setOf("accounts.google.com", "accounts.youtube.com")

    sealed interface Decision {
        data object Allow : Decision
        data class Deny(val reason: String) : Decision
    }

    sealed interface Input {
        data object Extensions : Input
        data class Navigate(val url: String) : Input
        data class Blocked(val reason: String) : Input
    }

    /** Decision for a load that Gecko wants to perform (top-level, redirect or sub-frame). */
    fun evaluate(url: String?, subframe: Boolean = false): Decision {
        val text = url?.trim().orEmpty()
        if (text.isEmpty()) return Decision.Deny("empty url")
        if (text.equals("about:blank", ignoreCase = true)) return Decision.Allow
        val uri = try { URI(text) } catch (e: Exception) { return Decision.Deny("malformed url") }
        val scheme = uri.scheme?.lowercase() ?: return Decision.Deny("no scheme")
        if (subframe && (scheme == "about" || scheme == "blob")) return Decision.Allow
        if (scheme != "https") return Decision.Deny("scheme $scheme is not allowed")
        if (uri.userInfo != null) return Decision.Deny("credentials in url")
        if (uri.port != -1 && uri.port != 443) return Decision.Deny("port ${uri.port} is not allowed")
        val host = uri.host?.lowercase() ?: return Decision.Deny("no host")
        if (host == YOUTUBE_HOST) return Decision.Allow
        if (ALLOW_GOOGLE_SIGN_IN && host in SIGN_IN_HOSTS) return Decision.Allow
        return Decision.Deny("$host is not allowed")
    }

    /** Turns what the user typed in the address bar into an action. */
    fun resolveInput(input: String): Input {
        val t = input.trim()
        if (t.isEmpty()) return Input.Navigate(HOME)
        if (t.equals(EXTENSIONS_URL, true) || t.equals("$EXTENSIONS_URL/", true)) return Input.Extensions

        val looksLikeUrl = !t.contains(' ') && (t.contains('.') || t.contains("://"))
        if (!looksLikeUrl) {
            // Not a URL: search YouTube (there is no other search engine in NEXORA).
            return Input.Navigate("https://www.youtube.com/results?search_query=" + URLEncoder.encode(t, "UTF-8"))
        }
        var candidate = if (t.contains("://")) t else "https://$t"
        try {
            val u = URI(candidate)
            val h = u.host?.lowercase()
            // Typing convenience only; it is not an allowance for those hosts.
            if (u.scheme.equals("https", true) && (h == "youtube.com" || h == "m.youtube.com")) {
                candidate = URI(u.scheme, u.userInfo, YOUTUBE_HOST, u.port, u.path, u.query, u.fragment).toString()
            }
        } catch (e: Exception) { /* evaluate() below rejects it */ }
        return when (val d = evaluate(candidate)) {
            is Decision.Allow -> Input.Navigate(candidate)
            is Decision.Deny -> Input.Blocked(d.reason)
        }
    }
}
