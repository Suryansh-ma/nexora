/*
 * Copyright (C) 2026 NEXORA contributors
 * SPDX-License-Identifier: GPL-3.0-only
 */
package app.nexora.browser

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.nexora.browser.databinding.ActivityMainBinding
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var runtime: GeckoRuntime
    private lateinit var session: GeckoSession
    private lateinit var host: ExtensionHost
    private lateinit var page: ExtensionsPage

    private val handler = Handler(Looper.getMainLooper())
    private var startupDone = false
    private var canGoBack = false
    private var canGoForward = false
    private var fullscreen = false
    private var extensionsVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !startupDone }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        applyInsets()

        runtime = (application as NexoraApp).runtime
        host = ExtensionHost(this, runtime)
        page = ExtensionsPage(this, b.extensionsPage, host) { enabled -> onExtensionToggled(enabled) }

        session = GeckoSession(
            GeckoSessionSettings.Builder()
                .usePrivateMode(false)
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_DESKTOP)
                .displayMode(GeckoSessionSettings.DISPLAY_MODE_BROWSER)
                .allowJavascript(true)
                .build()
        )
        attachDelegates()
        session.open(runtime)
        b.geckoView.setSession(session)

        setupToolbar()
        setupBackHandling()
        updateNavButtons()

        // Install the bundled extension BEFORE the first page load so its document_start
        // content scripts apply to the very first YouTube document. Safety net: never hold the
        // splash screen for more than 10 seconds.
        handler.postDelayed({ finishStartup() }, 10_000)
        host.ensureInstalled { finishStartup() }
    }

    private fun finishStartup() {
        if (startupDone) return
        startupDone = true
        handler.removeCallbacksAndMessages(null)
        page.render()
        if (host.installError != null) {
            Toast.makeText(this, "Desktop GIFs failed to load: ${host.installError}", Toast.LENGTH_LONG).show()
        }
        session.loadUri(UrlPolicy.HOME)
    }

    // ---------------------------------------------------------------- Gecko delegates

    private fun attachDelegates() {
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean,
            ) {
                runOnUiThread { if (!extensionsVisible && !b.addressBar.hasFocus()) b.addressBar.setText(url.orEmpty()) }
            }

            override fun onCanGoBack(session: GeckoSession, value: Boolean) {
                canGoBack = value
                runOnUiThread { updateNavButtons() }
            }

            override fun onCanGoForward(session: GeckoSession, value: Boolean) {
                canGoForward = value
                runOnUiThread { updateNavButtons() }
            }

            // Top-level loads AND redirects both arrive here, so a redirect off youtube.com is denied.
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest,
            ): GeckoResult<AllowOrDeny>? = decide(request.uri, subframe = false)

            override fun onSubframeLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest,
            ): GeckoResult<AllowOrDeny>? = decide(request.uri, subframe = true)

            // window.open / target=_blank: keep everything inside this one session.
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                if (UrlPolicy.evaluate(uri) is UrlPolicy.Decision.Allow) {
                    runOnUiThread { this@MainActivity.session.loadUri(uri) }
                } else {
                    runOnUiThread { toastBlocked() }
                }
                return null
            }
        }

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                runOnUiThread {
                    b.progress.progress = 0
                    if (!fullscreen) b.progress.visibility = View.VISIBLE
                    b.btnReload.contentDescription = "Reload"
                }
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                runOnUiThread { b.progress.progress = progress }
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                runOnUiThread { b.progress.visibility = View.INVISIBLE }
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                runOnUiThread { setFullscreen(fullScreen) }
            }

            override fun onCrash(session: GeckoSession) = recover()
            override fun onKill(session: GeckoSession) = recover()
        }
    }

    private fun decide(uri: String?, subframe: Boolean): GeckoResult<AllowOrDeny> =
        when (UrlPolicy.evaluate(uri, subframe)) {
            is UrlPolicy.Decision.Allow -> GeckoResult.fromValue(AllowOrDeny.ALLOW)
            is UrlPolicy.Decision.Deny -> {
                if (!subframe) runOnUiThread { toastBlocked() }
                GeckoResult.fromValue(AllowOrDeny.DENY)
            }
        }

    private fun recover() {
        runOnUiThread {
            session.open(runtime)
            b.geckoView.setSession(session)
            session.loadUri(UrlPolicy.HOME)
        }
    }

    // ---------------------------------------------------------------- UI

    private fun setupToolbar() {
        b.btnBack.setOnClickListener { if (extensionsVisible) showExtensions(false) else session.goBack() }
        b.btnForward.setOnClickListener { session.goForward() }
        b.btnReload.setOnClickListener { if (extensionsVisible) page.render() else session.reload() }
        b.btnHome.setOnClickListener { navigate(UrlPolicy.HOME) }
        b.btnExtensions.setOnClickListener { showExtensions(!extensionsVisible) }

        b.addressBar.setOnEditorActionListener { v, actionId, event ->
            val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                navigate(v.text.toString())
                v.clearFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
                true
            } else false
        }
    }

    private fun navigate(input: String) {
        when (val r = UrlPolicy.resolveInput(input)) {
            is UrlPolicy.Input.Extensions -> showExtensions(true)
            is UrlPolicy.Input.Navigate -> {
                showExtensions(false)
                session.loadUri(r.url)
            }
            is UrlPolicy.Input.Blocked -> toastBlocked()
        }
    }

    private fun showExtensions(show: Boolean) {
        extensionsVisible = show
        b.extensionsPage.root.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            page.render()
            b.addressBar.setText(UrlPolicy.EXTENSIONS_URL)
        }
        updateNavButtons()
    }

    private fun onExtensionToggled(enabled: Boolean) {
        host.setEnabled(enabled) {
            runOnUiThread {
                page.render()
                // Content scripts are added/removed at document load, so reload to apply.
                session.reload()
            }
        }
    }

    private fun updateNavButtons() {
        b.btnBack.isEnabled = extensionsVisible || canGoBack
        b.btnForward.isEnabled = !extensionsVisible && canGoForward
    }

    private fun toastBlocked() = Toast.makeText(this, R.string.blocked, Toast.LENGTH_SHORT).show()

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    fullscreen -> session.exitFullScreen()
                    extensionsVisible -> showExtensions(false)
                    canGoBack -> session.goBack()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    private fun applyInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            if (fullscreen) v.setPadding(0, 0, 0, 0)
            else v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        val chrome = if (on) View.GONE else View.VISIBLE
        b.topBar.visibility = chrome
        b.bottomBar.visibility = chrome
        if (on) b.progress.visibility = View.GONE
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        ViewCompat.requestApplyInsets(b.root)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        session.close()
        super.onDestroy()
    }
}
