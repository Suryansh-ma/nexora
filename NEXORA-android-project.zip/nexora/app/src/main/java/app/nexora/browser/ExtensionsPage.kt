/*
 * Copyright (C) 2026 NEXORA contributors
 * SPDX-License-Identifier: GPL-3.0-only
 */
package app.nexora.browser

import android.content.Context
import android.graphics.BitmapFactory
import androidx.core.content.ContextCompat
import app.nexora.browser.databinding.ViewExtensionsBinding
import org.json.JSONObject

/**
 * Native renderer for nexora://extensions. Everything shown is read from the live GeckoView
 * WebExtension object or from the bundled manifest.json - nothing is hard-coded about the
 * extension except the explanatory notes below.
 */
class ExtensionsPage(
    private val context: Context,
    private val b: ViewExtensionsBinding,
    private val host: ExtensionHost,
    private val onToggle: (Boolean) -> Unit,
) {
    private val manifest: JSONObject? = try {
        context.assets.open("${ExtensionHost.ASSET_DIR}/manifest.json").bufferedReader().use { JSONObject(it.readText()) }
    } catch (e: Exception) { null }

    init {
        try {
            context.assets.open("${ExtensionHost.ASSET_DIR}/icons/icon-128.png").use {
                b.extIcon.setImageBitmap(BitmapFactory.decodeStream(it))
            }
        } catch (e: Exception) { /* icon is cosmetic */ }
        b.extSwitch.setOnCheckedChangeListener { _, checked -> onToggle(checked) }
    }

    fun render() {
        val ext = host.extension
        val meta = ext?.metaData

        b.extName.text = meta?.name ?: manifest?.optString("name") ?: "Desktop GIFs"
        b.extVersion.text = "Version " + (meta?.version ?: manifest?.optString("version") ?: "unknown")
        b.extDescription.text = meta?.description ?: manifest?.optString("description").orEmpty()

        val enabled = meta?.enabled == true
        b.extStatus.text = when {
            ext == null -> "Not installed"
            enabled -> "Installed · Enabled"
            else -> "Installed · Disabled"
        }
        b.extStatus.setTextColor(ContextCompat.getColor(context, when {
            ext == null -> R.color.nx_danger
            enabled -> R.color.nx_ok
            else -> R.color.nx_warn
        }))

        b.extSwitch.setOnCheckedChangeListener(null)
        b.extSwitch.isChecked = enabled
        b.extSwitch.isEnabled = ext != null
        b.extSwitch.setOnCheckedChangeListener { _, checked -> onToggle(checked) }

        val gecko = manifest?.optJSONObject("browser_specific_settings")?.optJSONObject("gecko")
        b.extDetails.text = buildString {
            append("ID: ").append(ExtensionHost.EXTENSION_ID).append('\n')
            append("Source: bundled inside the NEXORA APK (no download)\n")
            append("Manifest version: ").append(manifest?.optInt("manifest_version", 0) ?: "?").append('\n')
            append("Engine: GeckoView (Gecko ").append(gecko?.optString("strict_min_version", "?")).append("+ required)\n")
            append("Background: ").append(
                if (manifest?.optJSONObject("background")?.has("scripts") == true)
                    "event page (background.scripts; the service_worker key is ignored by Gecko)"
                else "unknown"
            ).append('\n')
            append("Content scripts: ").append(manifest?.optJSONArray("content_scripts")?.length() ?: 0)
            append(" (one in the MAIN world)\n")
            append("License: GPL-3.0-only (see Licenses in the project)")
            host.installError?.let { append("\n\nError: ").append(it) }
        }

        val perms = meta?.permissions?.toList().orEmpty().ifEmpty { jsonList("permissions") }
        b.extPermissions.text = if (perms.isEmpty()) "None reported" else perms.joinToString("\n") { "• $it — ${describe(it)}" }

        val origins = meta?.origins?.toList().orEmpty().ifEmpty { jsonList("host_permissions") }
        b.extOrigins.text = (if (origins.isEmpty()) "None reported" else origins.joinToString("\n") { "• $it" }) +
            "\n\nAlso contacted by the extension's own code (CORS): tenor.googleapis.com (search), " +
            "media.tenor.com (previews) and api.github.com (once-a-day update check)."

        b.extNotes.text = "The extension's README reports that since 14 Oct 2026 YouTube rejects GIF comments sent " +
            "from desktop clients. Search, the picker and favorites are separate from posting. " +
            "Posting also needs a signed-in YouTube account; NEXORA allows Google/YouTube sign-in pages (accounts.google.com, accounts.youtube.com) for that."
    }

    private fun jsonList(key: String): List<String> {
        val arr = manifest?.optJSONArray(key) ?: return emptyList()
        return (0 until arr.length()).map { arr.getString(it) }
    }

    private fun describe(permission: String) = when (permission) {
        "scripting" -> "inject the GIF button/picker scripts into YouTube tabs"
        "storage" -> "keep favorites and cached Tenor settings on this device"
        else -> "declared by the extension"
    }
}
