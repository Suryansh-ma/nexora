# NEXORA — Testing report

**Honest status: the app has NOT been compiled, installed or run.** The environment this was produced in had no Android SDK, no Gradle, and no access to Google/Mozilla Maven repositories, and no device or emulator. No APK exists. Everything below marked NOT RUN must be performed on your side.

## What was actually run
| Check | Result |
| --- | --- |
| Extension inspected: manifest, `sw.js`, `content.js`, `main.js` | Done. Uses `scripting`, `storage`, MAIN-world content script, background script, `runtime.sendMessage` — all supported by Gecko 140+ (manifest requires `strict_min_version` 140). |
| Bundled extension identical to the supplied ZIP (`diff -r`) | PASS (byte-identical) |
| Extension's own tests: `node --test tests/main.test.cjs tests/sw.test.cjs` | PASS 43/43 (simulated responses; not on a device) |
| All Android XML resources + manifest well-formed | PASS (parse check only; not aapt-validated) |
| Kotlin / Gradle compile | **NOT RUN** — written against GeckoView's API from memory; method signatures (e.g. `onLocationChange`, `ensureBuiltIn`, `GeckoResult.then`) may need small fixes on first compile |

## Required on-device tests (all NOT RUN)
| # | Test | How to verify | Result |
| - | --- | --- | --- |
| 1 | Install & launch | `adb install`, open NEXORA, splash then YouTube | NOT RUN |
| 2 | YouTube desktop mode | Desktop layout (no m.youtube bottom nav); in debug build open `about:` not available — check page has desktop masthead | NOT RUN |
| 3 | Extension auto-loaded | Extensions button → Desktop GIFs, v0.1.8, "Installed · Enabled" | NOT RUN |
| 4 | GIF button in comments | Open a video, scroll to comments, tap "Add a comment…": GIF button beside emoji button | NOT RUN |
| 5 | Search / picker | Open picker: featured GIFs load; type "cat"; paste a tenor.com/view link | NOT RUN |
| 6 | Storage / favorites | Star a GIF, force-stop app, relaunch, open favorites (★) | NOT RUN |
| 7 | Site restrictions | Type `google.com` (blocked toast); click YouTube links to external sites; try `http://youtube.com` | NOT RUN |
| 8 | Back & fullscreen | Android back through history; play video → fullscreen → back exits fullscreen | NOT RUN |
| 9 | Posting a GIF | Requires sign-in (now allowed via accounts.google.com / accounts.youtube.com) and upstream reports YouTube rejects it | NOT RUN — **no claim that posting works** |

## Known risks to check first
* **Host permissions:** Firefox MV3 may not auto-grant `host_permissions` to a built-in extension. If search shows "not allowed to reach tenor.com", the grant is missing (details in README note and nexora://extensions "Site access").
* **GeckoView version** string in `gradle.properties` is unverified.
* **Desktop mode** uses Gecko's own desktop UA (a Firefox UA), not a spoofed Chrome UA.
* **Sign-in** is allowed for accounts.google.com / accounts.youtube.com; Google's login may involve other hosts that would still be blocked.
