# Third-party software in NEXORA

## Desktop GIFs (bundled, unmodified)
- Path: `app/src/main/assets/extensions/desktop-gifs/` (byte-identical copy of `desktop_gifs-main/extension/`, v0.1.8)
- Copyright (C) 2026 rayytor — GNU GPL v3 only. Upstream: https://github.com/rayytor/desktop_gifs
- Not affiliated with YouTube, Google or Tenor.

## GeckoView
- Mozilla GeckoView (`org.mozilla.geckoview:geckoview`), Mozilla Public License 2.0 and bundled third-party components. https://www.mozilla.org/MPL/2.0/

## AndroidX (appcompat, core-ktx, core-splashscreen)
- Apache License 2.0.

## NEXORA itself
- Copyright (C) 2026 NEXORA contributors — GNU GPL v3 only (required because it is distributed together with the GPL-3.0 extension).
- The complete corresponding source of any APK built from this tree is this tree. If you distribute an APK, you must offer this source to recipients under GPL-3.0.
