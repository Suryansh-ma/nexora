#!/usr/bin/env bash
# Confirms the bundled extension is byte-identical to the upstream ZIP you supplied.
# Usage: scripts/verify-extension.sh /path/to/desktop_gifs-main.zip
set -euo pipefail
tmp=$(mktemp -d); unzip -q "$1" -d "$tmp"
diff -r "$tmp/desktop_gifs-main/extension" "$(dirname "$0")/../app/src/main/assets/extensions/desktop-gifs" \
  && echo "OK: bundled extension is identical to upstream"
